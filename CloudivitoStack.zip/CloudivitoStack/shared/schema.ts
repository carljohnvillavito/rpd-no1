import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  company: varchar("company"),
  subscriptionPlan: varchar("subscription_plan").notNull().default("free"),
  subscriptionStatus: varchar("subscription_status").default("active"),
  subscriptionExpiry: timestamp("subscription_expiry"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cloud instances table
export const instances = pgTable("instances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  type: varchar("type").notNull(), // t3.micro, t3.small, etc.
  status: varchar("status").notNull().default("stopped"), // running, stopped, starting, stopping
  ipAddress: varchar("ip_address"),
  operatingSystem: varchar("operating_system").notNull(),
  storageSize: integer("storage_size").notNull(), // in GB
  incusContainerId: varchar("incus_container_id"),
  monthlyEstimate: decimal("monthly_estimate", { precision: 10, scale: 2 }),
  vcpu: decimal("vcpu", { precision: 3, scale: 1 }).notNull().default("1.0"),
  memory: varchar("memory").notNull().default("500MiB"),
  createdByPlan: varchar("created_by_plan").notNull().default("free"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Billing records table
export const billingRecords = pgTable("billing_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  status: varchar("status").notNull().default("pending"), // pending, paid, failed
  billingDate: timestamp("billing_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Usage tracking table
export const usageMetrics = pgTable("usage_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  instanceId: varchar("instance_id").references(() => instances.id, { onDelete: "cascade" }),
  metricType: varchar("metric_type").notNull(), // compute_hours, storage_gb, data_transfer_gb
  value: decimal("value", { precision: 15, scale: 6 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  instances: many(instances),
  billingRecords: many(billingRecords),
  usageMetrics: many(usageMetrics),
}));

export const instancesRelations = relations(instances, ({ one, many }) => ({
  user: one(users, {
    fields: [instances.userId],
    references: [users.id],
  }),
  usageMetrics: many(usageMetrics),
}));

export const billingRecordsRelations = relations(billingRecords, ({ one }) => ({
  user: one(users, {
    fields: [billingRecords.userId],
    references: [users.id],
  }),
}));

export const usageMetricsRelations = relations(usageMetrics, ({ one }) => ({
  user: one(users, {
    fields: [usageMetrics.userId],
    references: [users.id],
  }),
  instance: one(instances, {
    fields: [usageMetrics.instanceId],
    references: [instances.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertInstanceSchema = createInsertSchema(instances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBillingRecordSchema = createInsertSchema(billingRecords).omit({
  id: true,
  createdAt: true,
});

export const insertUsageMetricSchema = createInsertSchema(usageMetrics).omit({
  id: true,
  timestamp: true,
});

// Subscription plans definition
export const subscriptionPlans = {
  free: {
    name: "Free Plan",
    price: 0,
    currency: "₱",
    instanceLimit: 3,
    vcpu: 1.0,
    memory: "500MiB",
    features: ["3 instance limit", "1.0 vCPU per instance", "500MiB Memory per instance"]
  },
  basic: {
    name: "Basic Plan", 
    price: 75,
    currency: "₱",
    instanceLimit: 6,
    vcpu: 2.5,
    memory: "1GiB",
    features: ["6 instance limit", "2.5 vCPU per instance", "1GiB Memory per instance"]
  },
  pro: {
    name: "Pro Plan",
    price: 175, 
    currency: "₱",
    instanceLimit: 12,
    vcpu: 4.0,
    memory: "5GiB",
    features: ["12 instance limit", "4.0 vCPU per instance", "5GiB Memory per instance"]
  },
  business: {
    name: "Business Plan",
    price: 250,
    currency: "₱", 
    instanceLimit: 35,
    vcpu: 8.0,
    memory: "12GiB",
    features: ["35 instance limit", "8.0 vCPU per instance", "12GiB Memory per instance"]
  }
} as const;

export type SubscriptionPlanType = keyof typeof subscriptionPlans;

export const updateUserSubscriptionSchema = createInsertSchema(users).pick({
  subscriptionPlan: true,
  subscriptionExpiry: true,
}).extend({
  subscriptionPlan: z.enum(["free", "basic", "pro", "business"]),
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertInstance = z.infer<typeof insertInstanceSchema>;
export type Instance = typeof instances.$inferSelect;
export type InsertBillingRecord = z.infer<typeof insertBillingRecordSchema>;
export type BillingRecord = typeof billingRecords.$inferSelect;
export type InsertUsageMetric = z.infer<typeof insertUsageMetricSchema>;
export type UsageMetric = typeof usageMetrics.$inferSelect;
export type UpdateUserSubscription = z.infer<typeof updateUserSubscriptionSchema>;
