import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Server, Shield, TrendingUp, Globe, DollarSign, Rocket } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleGetStarted = () => {
    window.location.href = "/api/login";
  };

  const features = [
    {
      icon: <Rocket className="w-6 h-6" />,
      title: "Instant Deployment",
      description: "Deploy your applications in seconds with our automated container orchestration powered by Incus technology.",
      color: "bg-aws-accent text-white"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Enterprise Security",
      description: "Industry-leading security with encrypted storage, network isolation, and comprehensive access controls.",
      color: "bg-aws-success text-white"
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Auto Scaling",
      description: "Automatically scale your resources up or down based on demand with intelligent load balancing.",
      color: "bg-aws-secondary text-white"
    },
    {
      icon: <Server className="w-6 h-6" />,
      title: "Real-time Monitoring",
      description: "Comprehensive monitoring and alerting with detailed metrics and performance insights.",
      color: "bg-purple-600 text-white"
    },
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Global Network",
      description: "Deploy across multiple regions with automatic IP assignment and load distribution.",
      color: "bg-red-600 text-white"
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "Flexible Billing",
      description: "Pay only for what you use with transparent pricing and automated billing management.",
      color: "bg-green-600 text-white"
    }
  ];

  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "per month",
      features: [
        "1 Container Instance",
        "1GB RAM",
        "10GB Storage",
        "Basic Support"
      ],
      buttonText: "Get Started",
      buttonVariant: "outline" as const,
      popular: false
    },
    {
      name: "Pro",
      price: "$29",
      period: "per month",
      features: [
        "5 Container Instances",
        "8GB RAM per instance",
        "100GB Storage",
        "Priority Support",
        "Auto Scaling"
      ],
      buttonText: "Start Free Trial",
      buttonVariant: "default" as const,
      popular: true
    },
    {
      name: "Enterprise",
      price: "$99",
      period: "per month",
      features: [
        "Unlimited Instances",
        "32GB RAM per instance",
        "1TB Storage",
        "24/7 Dedicated Support",
        "Advanced Analytics"
      ],
      buttonText: "Contact Sales",
      buttonVariant: "outline" as const,
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-aws-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span className="text-2xl font-bold text-aws-primary" data-testid="logo">Cloudivito</span>
              </div>
              <div className="hidden lg:block ml-10">
                <div className="flex items-baseline space-x-8">
                  <a href="#features" className="text-aws-text hover:text-aws-accent px-3 py-2 text-sm font-medium" data-testid="link-features">Features</a>
                  <a href="#pricing" className="text-aws-text hover:text-aws-accent px-3 py-2 text-sm font-medium" data-testid="link-pricing">Pricing</a>
                  <a href="#" className="text-aws-text hover:text-aws-accent px-3 py-2 text-sm font-medium" data-testid="link-docs">Documentation</a>
                  <a href="#" className="text-aws-text hover:text-aws-accent px-3 py-2 text-sm font-medium" data-testid="link-support">Support</a>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2 md:space-x-4">
              <Button variant="ghost" onClick={handleLogin} data-testid="button-signin">
                Sign In
              </Button>
              <Button onClick={handleGetStarted} className="bg-aws-secondary hover:bg-orange-600" data-testid="button-get-started">
                Get Started
              </Button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-aws-primary to-blue-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6" data-testid="text-hero-title">
                Cloud Infrastructure
                <span className="text-aws-secondary"> Simplified</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed" data-testid="text-hero-description">
                Deploy, manage, and scale your applications with our powerful cloud platform. Built on proven container technology with automatic scaling and comprehensive monitoring.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" onClick={handleGetStarted} className="bg-aws-secondary hover:bg-orange-600" data-testid="button-start-trial">
                  Start Free Trial
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-aws-primary" data-testid="button-view-demo">
                  View Demo
                </Button>
              </div>
            </div>
            <div className="relative">
              {/* Modern cloud infrastructure illustration */}
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 shadow-2xl">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-aws-accent/20 rounded-lg p-4 text-center">
                    <Server className="w-8 h-8 text-aws-secondary mb-2 mx-auto" />
                    <p className="text-sm">Containers</p>
                  </div>
                  <div className="bg-aws-accent/20 rounded-lg p-4 text-center">
                    <Globe className="w-8 h-8 text-aws-secondary mb-2 mx-auto" />
                    <p className="text-sm">Networking</p>
                  </div>
                  <div className="bg-aws-accent/20 rounded-lg p-4 text-center">
                    <Shield className="w-8 h-8 text-aws-secondary mb-2 mx-auto" />
                    <p className="text-sm">Storage</p>
                  </div>
                  <div className="bg-aws-accent/20 rounded-lg p-4 text-center">
                    <TrendingUp className="w-8 h-8 text-aws-secondary mb-2 mx-auto" />
                    <p className="text-sm">Analytics</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-aws-primary mb-4" data-testid="text-features-title">
              Enterprise-Grade Cloud Infrastructure
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-features-description">
              Everything you need to deploy, manage, and scale your applications in the cloud with confidence.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow" data-testid={`card-feature-${index}`}>
                <CardContent className="p-8">
                  <div className={`${feature.color} w-12 h-12 rounded-lg flex items-center justify-center mb-6`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-4" data-testid={`text-feature-title-${index}`}>{feature.title}</h3>
                  <p className="text-gray-600" data-testid={`text-feature-description-${index}`}>{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-aws-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-aws-primary mb-4" data-testid="text-pricing-title">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600" data-testid="text-pricing-description">
              Choose the perfect plan for your needs. Start free and scale as you grow.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative ${plan.popular ? 'border-2 border-aws-secondary' : 'border border-gray-200'}`}
                data-testid={`card-plan-${plan.name.toLowerCase()}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-aws-secondary text-white px-4 py-2 rounded-full text-sm font-semibold" data-testid="badge-popular">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold mb-2" data-testid={`text-plan-name-${plan.name.toLowerCase()}`}>{plan.name}</h3>
                    <div className="text-4xl font-bold text-aws-primary mb-2" data-testid={`text-plan-price-${plan.name.toLowerCase()}`}>{plan.price}</div>
                    <p className="text-gray-600" data-testid={`text-plan-period-${plan.name.toLowerCase()}`}>{plan.period}</p>
                  </div>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center" data-testid={`text-plan-feature-${plan.name.toLowerCase()}-${featureIndex}`}>
                        <CheckCircle className="w-5 h-5 text-aws-success mr-3" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${plan.popular ? 'bg-aws-secondary hover:bg-orange-600' : ''}`}
                    variant={plan.buttonVariant}
                    onClick={handleGetStarted}
                    data-testid={`button-plan-${plan.name.toLowerCase()}`}
                  >
                    {plan.buttonText}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-aws-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4" data-testid="text-footer-brand">Cloudivito</h3>
              <p className="text-gray-300" data-testid="text-footer-description">Modern cloud infrastructure platform built for developers and enterprises.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="text-footer-product">Product</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#features" className="hover:text-white" data-testid="link-footer-features">Features</a></li>
                <li><a href="#pricing" className="hover:text-white" data-testid="link-footer-pricing">Pricing</a></li>
                <li><a href="#" className="hover:text-white" data-testid="link-footer-docs">Documentation</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="text-footer-company">Company</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white" data-testid="link-footer-about">About</a></li>
                <li><a href="#" className="hover:text-white" data-testid="link-footer-blog">Blog</a></li>
                <li><a href="#" className="hover:text-white" data-testid="link-footer-careers">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4" data-testid="text-footer-support">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white" data-testid="link-footer-help">Help Center</a></li>
                <li><a href="#" className="hover:text-white" data-testid="link-footer-contact">Contact</a></li>
                <li><a href="#" className="hover:text-white" data-testid="link-footer-status">Status</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p data-testid="text-footer-copyright">&copy; 2024 Cloudivito. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
