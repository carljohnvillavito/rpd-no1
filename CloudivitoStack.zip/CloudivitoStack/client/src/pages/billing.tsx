import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Check, CreditCard, Crown, Star, Zap, Menu, User } from "lucide-react";
import Sidebar from "@/components/dashboard/sidebar";

const subscriptionPlans = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    currency: '₱',
    period: 'month',
    description: 'Perfect for getting started',
    features: [
      '3 instances maximum',
      '1.0 vCPU per instance',
      '500MiB memory per instance',
      'Community support',
      'Basic monitoring'
    ],
    limits: {
      instances: 3,
      vcpu: 1.0,
      memory: '500MiB'
    },
    color: 'bg-gray-100',
    iconBg: 'bg-gray-500',
    icon: Star
  },
  {
    id: 'basic',
    name: 'Basic Plan',
    price: 75,
    currency: '₱',
    period: 'month',
    description: 'Great for small projects',
    features: [
      '6 instances maximum',
      '2.5 vCPU per instance',
      '1GiB memory per instance',
      'Email support',
      'Advanced monitoring',
      'Automated backups'
    ],
    limits: {
      instances: 6,
      vcpu: 2.5,
      memory: '1GiB'
    },
    color: 'bg-blue-50',
    iconBg: 'bg-blue-500',
    icon: Zap
  },
  {
    id: 'pro',
    name: 'Pro Plan',
    price: 175,
    currency: '₱',
    period: 'month',
    description: 'For growing businesses',
    features: [
      '12 instances maximum',
      '4.0 vCPU per instance',
      '5GiB memory per instance',
      'Priority email support',
      'Advanced monitoring & alerts',
      'Automated backups',
      'Load balancing'
    ],
    limits: {
      instances: 12,
      vcpu: 4.0,
      memory: '5GiB'
    },
    color: 'bg-orange-50',
    iconBg: 'bg-orange-500',
    icon: Crown,
    popular: true
  },
  {
    id: 'business',
    name: 'Business Plan',
    price: 250,
    currency: '₱',
    period: 'month',
    description: 'For enterprise applications',
    features: [
      '35 instances maximum',
      '8.0 vCPU per instance',
      '12GiB memory per instance',
      '24/7 phone & email support',
      'Advanced monitoring & alerts',
      'Automated backups',
      'Load balancing',
      'Custom integrations'
    ],
    limits: {
      instances: 35,
      vcpu: 8.0,
      memory: '12GiB'
    },
    color: 'bg-purple-50',
    iconBg: 'bg-purple-500',
    icon: CreditCard
  }
];

export default function BillingPage() {
  const [currentPlan] = useState('free'); // This would come from user's subscription
  const [instancesUsed] = useState(0); // This would come from API
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const currentPlanData = subscriptionPlans.find(plan => plan.id === currentPlan);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden h-8 w-8"
              data-testid="button-mobile-menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-lg font-semibold text-aws-text" data-testid="text-page-title">Billing & Subscription</h1>
              <p className="text-xs text-gray-500 hidden sm:block">Manage your subscription and billing</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-6 h-6 bg-aws-primary rounded-full flex items-center justify-center" data-testid="icon-profile">
                <User className="w-3 h-3 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:block w-64 bg-white border-r border-gray-200 h-[calc(100vh-73px)] sticky top-[73px]">
          <div className="p-6">
            <Sidebar />
          </div>
        </aside>

        {/* Mobile Sidebar */}
        <Sidebar isMobileMenuOpen={isMobileMenuOpen} onMobileMenuClose={() => setIsMobileMenuOpen(false)} />

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <div className="max-w-6xl mx-auto space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-aws-text mb-2" data-testid="text-billing-title">
          Billing & Subscription
        </h2>
        <p className="text-gray-600" data-testid="text-billing-description">
          Manage your subscription plan and view billing information
        </p>
      </div>

      {/* Current Plan */}
      {currentPlanData && (
        <Card className="border-2 border-aws-primary" data-testid="card-current-plan">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <div className={`w-8 h-8 rounded-full ${currentPlanData.iconBg} flex items-center justify-center`}>
                  <currentPlanData.icon className="w-4 h-4 text-white" />
                </div>
                <span>Current Plan: {currentPlanData.name}</span>
              </span>
              <Badge className="bg-aws-primary text-white">Active</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-bold">
              {currentPlanData.currency}{currentPlanData.price}
              <span className="text-lg text-gray-600">/{currentPlanData.period}</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Instances Used</span>
                <span>{instancesUsed} / {currentPlanData.limits.instances}</span>
              </div>
              <Progress 
                value={(instancesUsed / currentPlanData.limits.instances) * 100} 
                className="h-2"
                data-testid="progress-instances-usage"
              />
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">vCPU per instance</span>
                <div className="font-medium">{currentPlanData.limits.vcpu}</div>
              </div>
              <div>
                <span className="text-gray-600">Memory per instance</span>
                <div className="font-medium">{currentPlanData.limits.memory}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Plans */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-aws-text">Available Plans</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {subscriptionPlans.map((plan) => {
            const Icon = plan.icon;
            const isCurrent = plan.id === currentPlan;
            
            return (
              <Card 
                key={plan.id} 
                className={`relative ${plan.color} ${plan.popular ? 'border-2 border-orange-500' : ''}`}
                data-testid={`card-plan-${plan.id}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-orange-500 text-white">Most Popular</Badge>
                  </div>
                )}
                
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full ${plan.iconBg} flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      <p className="text-sm text-gray-600">{plan.description}</p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="text-2xl font-bold">
                    {plan.currency}{plan.price}
                    <span className="text-sm text-gray-600">/{plan.period}</span>
                  </div>
                  
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2 text-sm">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${
                      isCurrent 
                        ? 'bg-gray-400 cursor-not-allowed' 
                        : 'bg-aws-secondary hover:bg-orange-600'
                    }`}
                    disabled={isCurrent}
                    data-testid={`button-select-${plan.id}`}
                  >
                    {isCurrent ? 'Current Plan' : `Upgrade to ${plan.name}`}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Billing History */}
      <Card data-testid="card-billing-history">
        <CardHeader>
          <CardTitle>Billing History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-sm text-gray-500">No billing history available</p>
            <p className="text-xs text-gray-400 mt-1">Your payment history will appear here</p>
          </div>
        </CardContent>
      </Card>
          </div>
        </main>
      </div>
    </div>
  );
}