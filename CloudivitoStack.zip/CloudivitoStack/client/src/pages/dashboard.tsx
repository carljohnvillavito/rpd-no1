import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";
import { Route, Switch } from "wouter";
import Sidebar from "@/components/dashboard/sidebar";
import StatsOverview from "@/components/dashboard/stats-overview";
import InstancesSection from "@/components/dashboard/instances-section";
import BillingSection from "@/components/dashboard/billing-section";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Bell, LogOut, Menu } from "lucide-react";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-aws-bg flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-aws-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null; // Will redirect in useEffect
  }

  const userInitials = (user as User)?.firstName && (user as User)?.lastName 
    ? `${(user as User).firstName![0]}${(user as User).lastName![0]}`
    : (user as User)?.email?.charAt(0).toUpperCase() || 'U';

  const userDisplayName = (user as User)?.firstName && (user as User)?.lastName
    ? `${(user as User).firstName} ${(user as User).lastName}`
    : (user as User)?.email || 'User';

  return (
    <div className="min-h-screen bg-aws-bg">
      {/* Dashboard Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(true)}
                data-testid="button-mobile-menu"
              >
                <Menu className="h-6 w-6" />
              </Button>
              <h1 className="text-2xl font-bold text-aws-primary" data-testid="text-dashboard-title">Cloudivito Console</h1>
              <Badge className="bg-aws-success text-white" data-testid="badge-status">ONLINE</Badge>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <Avatar className="w-6 h-6" data-testid="avatar-user">
                  <AvatarImage src={(user as User)?.profileImageUrl || undefined} />
                  <AvatarFallback className="bg-aws-primary text-white text-xs">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
                <span className="text-xs font-medium hidden sm:inline" data-testid="text-username">{userDisplayName}</span>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleLogout} data-testid="button-logout">
                  <LogOut className="h-3 w-3 text-gray-500" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <Sidebar 
          isMobileMenuOpen={isMobileMenuOpen}
          onMobileMenuClose={() => setIsMobileMenuOpen(false)}
        />
        
        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6">
          <Switch>
            <Route path="/" component={StatsOverview} />
            <Route path="/instances" component={InstancesSection} />
            <Route path="/billing" component={BillingSection} />
            <Route path="/networking">
              <div className="text-center py-20">
                <div className="text-4xl text-gray-400 mb-4">🌐</div>
                <h2 className="text-2xl font-bold text-aws-text mb-6" data-testid="text-networking-title">Networking</h2>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                  <p className="text-gray-600" data-testid="text-networking-coming-soon">Networking management interface coming soon...</p>
                </div>
              </div>
            </Route>
            <Route path="/storage">
              <div className="text-center py-20">
                <div className="text-4xl text-gray-400 mb-4">💾</div>
                <h2 className="text-2xl font-bold text-aws-text mb-6" data-testid="text-storage-title">Storage</h2>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                  <p className="text-gray-600" data-testid="text-storage-coming-soon">Storage management interface coming soon...</p>
                </div>
              </div>
            </Route>
            <Route path="/monitoring">
              <div className="text-center py-20">
                <div className="text-4xl text-gray-400 mb-4">📊</div>
                <h2 className="text-2xl font-bold text-aws-text mb-6" data-testid="text-monitoring-title">Monitoring</h2>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                  <p className="text-gray-600" data-testid="text-monitoring-coming-soon">Monitoring dashboard coming soon...</p>
                </div>
              </div>
            </Route>
            <Route path="/settings">
              <div className="text-center py-20">
                <div className="text-4xl text-gray-400 mb-4">⚙️</div>
                <h2 className="text-2xl font-bold text-aws-text mb-6" data-testid="text-settings-title">Settings</h2>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                  <p className="text-gray-600" data-testid="text-settings-coming-soon">Settings interface coming soon...</p>
                </div>
              </div>
            </Route>
            <Route component={StatsOverview} />
          </Switch>
        </main>
      </div>
    </div>
  );
}
