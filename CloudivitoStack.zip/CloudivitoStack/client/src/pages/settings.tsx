import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import Sidebar from "@/components/dashboard/sidebar";
import { 
  User, 
  Bell, 
  Shield, 
  Database, 
  Trash2, 
  Download,
  Key,
  Menu
} from "lucide-react";

export default function SettingsPage() {
  const { user } = useAuth();
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [instanceAlerts, setInstanceAlerts] = useState(true);
  const [billingNotifications, setBillingNotifications] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden h-8 w-8"
              data-testid="button-mobile-menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-lg font-semibold text-aws-text" data-testid="text-page-title">Account Settings</h1>
              <p className="text-xs text-gray-500 hidden sm:block">Manage your account preferences</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-6 h-6 bg-aws-primary rounded-full flex items-center justify-center" data-testid="icon-profile">
                <User className="w-3 h-3 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:block w-64 bg-white border-r border-gray-200 h-[calc(100vh-73px)] sticky top-[73px]">
          <div className="p-6">
            <Sidebar />
          </div>
        </aside>

        {/* Mobile Sidebar */}
        <Sidebar isMobileMenuOpen={isMobileMenuOpen} onMobileMenuClose={() => setIsMobileMenuOpen(false)} />

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <div className="max-w-4xl mx-auto space-y-6">

      {/* Profile Settings */}
      <Card data-testid="card-profile-settings">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span>Profile Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="first-name">First Name</Label>
              <Input 
                id="first-name" 
                defaultValue={(user as any)?.firstName || ''} 
                data-testid="input-first-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last-name">Last Name</Label>
              <Input 
                id="last-name" 
                defaultValue={(user as any)?.lastName || ''} 
                data-testid="input-last-name"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input 
              id="email" 
              type="email" 
              defaultValue={(user as any)?.email || ''} 
              disabled 
              data-testid="input-email"
            />
            <p className="text-xs text-gray-500">Email cannot be changed</p>
          </div>

          <div className="flex items-center space-x-4 pt-4">
            {(user as any)?.profileImageUrl && (
              <img 
                src={(user as any).profileImageUrl} 
                alt="Profile" 
                className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
                data-testid="img-profile-avatar"
              />
            )}
            <div>
              <p className="text-sm font-medium">Profile Picture</p>
              <p className="text-xs text-gray-500">Managed through your authentication provider</p>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t">
            <Button className="bg-aws-secondary hover:bg-orange-600" data-testid="button-save-profile">
              Save Changes
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card data-testid="card-notification-settings">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="w-5 h-5" />
            <span>Notification Preferences</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="email-notifications">Email Notifications</Label>
              <p className="text-xs text-gray-500">Receive important updates via email</p>
            </div>
            <Switch 
              id="email-notifications" 
              checked={emailNotifications}
              onCheckedChange={setEmailNotifications}
              data-testid="switch-email-notifications"
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="instance-alerts">Instance Alerts</Label>
              <p className="text-xs text-gray-500">Get notified about instance status changes</p>
            </div>
            <Switch 
              id="instance-alerts" 
              checked={instanceAlerts}
              onCheckedChange={setInstanceAlerts}
              data-testid="switch-instance-alerts"
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="billing-notifications">Billing Notifications</Label>
              <p className="text-xs text-gray-500">Receive billing and payment reminders</p>
            </div>
            <Switch 
              id="billing-notifications" 
              checked={billingNotifications}
              onCheckedChange={setBillingNotifications}
              data-testid="switch-billing-notifications"
            />
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card data-testid="card-security-settings">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5" />
            <span>Security</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Key className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm font-medium">Authentication</p>
                <p className="text-xs text-gray-600">Secured via Replit authentication</p>
              </div>
            </div>
            <Badge className="bg-green-100 text-green-800">Secure</Badge>
          </div>
          
          <div className="text-xs text-gray-500 p-3 bg-gray-50 rounded-lg">
            Your account is secured through Replit's authentication system. 
            Password and security settings are managed through your Replit account.
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card data-testid="card-data-management">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="w-5 h-5" />
            <span>Data Management</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button 
              variant="outline" 
              className="flex items-center space-x-2 p-4 h-auto"
              data-testid="button-export-data"
            >
              <Download className="w-5 h-5" />
              <div className="text-left">
                <p className="font-medium">Export Data</p>
                <p className="text-xs text-gray-500">Download your instance data</p>
              </div>
            </Button>
            
            <Button 
              variant="destructive" 
              className="flex items-center space-x-2 p-4 h-auto"
              data-testid="button-delete-account"
            >
              <Trash2 className="w-5 h-5" />
              <div className="text-left">
                <p className="font-medium">Delete Account</p>
                <p className="text-xs opacity-80">Permanently delete your account</p>
              </div>
            </Button>
          </div>
          
          <div className="text-xs text-gray-500 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <strong>Warning:</strong> Deleting your account will permanently remove all instances, 
            billing history, and associated data. This action cannot be undone.
          </div>
        </CardContent>
      </Card>
          </div>
        </main>
      </div>
    </div>
  );
}