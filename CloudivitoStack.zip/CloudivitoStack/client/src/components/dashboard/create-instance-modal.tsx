import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

const createInstanceSchema = z.object({
  name: z.string().min(1, "Instance name is required").max(50, "Name must be less than 50 characters"),
  operatingSystem: z.enum(["debian/12", "ubuntu/24.04", "alpine/edge"]),
  storageSize: z.number().default(20),
  type: z.string().default("free-plan"),
});

type CreateInstanceForm = z.infer<typeof createInstanceSchema>;

interface CreateInstanceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CreateInstanceModal({ open, onOpenChange }: CreateInstanceModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CreateInstanceForm>({
    resolver: zodResolver(createInstanceSchema),
    defaultValues: {
      name: "",
      operatingSystem: "debian/12",
      storageSize: 20,
      type: "free-plan",
    },
  });

  const createInstanceMutation = useMutation({
    mutationFn: async (data: CreateInstanceForm) => {
      await apiRequest("POST", "/api/instances", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Instance created successfully",
      });
      onOpenChange(false);
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create instance",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CreateInstanceForm) => {
    createInstanceMutation.mutate(data);
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm mx-auto max-h-[85vh] overflow-y-auto" data-testid="modal-create-instance">
        <DialogHeader>
          <DialogTitle data-testid="text-modal-title">Create New Instance</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Instance Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="my-web-server" 
                      {...field} 
                      data-testid="input-instance-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />


            <FormField
              control={form.control}
              name="operatingSystem"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Operating System</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid grid-cols-1 gap-3"
                      data-testid="radio-operating-system"
                    >
                      <div className="flex items-center space-x-2 border border-gray-300 rounded-lg p-3 hover:bg-gray-50">
                        <RadioGroupItem value="debian/12" id="debian" />
                        <Label htmlFor="debian" className="flex-1 cursor-pointer">
                          <div className="font-medium text-sm">Debian 12</div>
                          <div className="text-xs text-gray-500">Stable release</div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border border-gray-300 rounded-lg p-3 hover:bg-gray-50">
                        <RadioGroupItem value="ubuntu/24.04" id="ubuntu" />
                        <Label htmlFor="ubuntu" className="flex-1 cursor-pointer">
                          <div className="font-medium text-sm">Ubuntu 24.04</div>
                          <div className="text-xs text-gray-500">Latest LTS release</div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border border-gray-300 rounded-lg p-3 hover:bg-gray-50">
                        <RadioGroupItem value="alpine/edge" id="alpine" />
                        <Label htmlFor="alpine" className="flex-1 cursor-pointer">
                          <div className="font-medium text-sm">Alpine Edge</div>
                          <div className="text-xs text-gray-500">Lightweight distro</div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Subscription Plan Display */}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="text-sm font-medium text-blue-800">Subscription Plan</div>
              <div className="text-xs text-blue-600">Free Plan</div>
            </div>

            <Card className="bg-gray-50" data-testid="card-instance-summary">
              <CardContent className="p-3">
                <h4 className="font-medium mb-2 text-sm" data-testid="text-summary-title">Summary</h4>
                <div className="text-xs text-gray-600 space-y-1">
                  <div data-testid="text-summary-ip">• Instance will be assigned an IP automatically</div>
                  <div>• 1.0 vCPU, 500MiB Memory (Free Plan limits)</div>
                  <div data-testid="text-summary-cost">
                    Monthly cost: <span className="font-medium text-aws-text">₱0.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row justify-end gap-4 sm:space-x-4 sm:gap-0">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createInstanceMutation.isPending}
                className="bg-aws-secondary hover:bg-orange-600"
                data-testid="button-create"
              >
                {createInstanceMutation.isPending ? "Creating..." : "Create Instance"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
