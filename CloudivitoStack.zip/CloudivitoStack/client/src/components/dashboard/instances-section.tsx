import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import CreateInstanceModal from "./create-instance-modal";
import { DataTable } from "@/components/ui/data-table";
import { Plus, Play, Square, Trash2 } from "lucide-react";
import { ColumnDef } from "@tanstack/react-table";
import type { Instance as InstanceType } from "@shared/schema";

interface Instance {
  id: string;
  name: string;
  status: string;
  type: string;
  ipAddress: string | null;
  operatingSystem: string;
  storageSize: number;
  createdAt: string;
}

export default function InstancesSection() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: instances = [], isLoading } = useQuery<Instance[]>({
    queryKey: ["/api/instances"],
  });

  const startInstanceMutation = useMutation({
    mutationFn: async (instanceId: string) => {
      await apiRequest("PATCH", `/api/instances/${instanceId}/start`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instances"] });
      toast({
        title: "Success",
        description: "Instance started successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start instance",
        variant: "destructive",
      });
    },
  });

  const stopInstanceMutation = useMutation({
    mutationFn: async (instanceId: string) => {
      await apiRequest("PATCH", `/api/instances/${instanceId}/stop`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instances"] });
      toast({
        title: "Success",
        description: "Instance stopped successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to stop instance",
        variant: "destructive",
      });
    },
  });

  const deleteInstanceMutation = useMutation({
    mutationFn: async (instanceId: string) => {
      await apiRequest("DELETE", `/api/instances/${instanceId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instances"] });
      toast({
        title: "Success",
        description: "Instance deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete instance",
        variant: "destructive",
      });
    },
  });

  const columns: ColumnDef<Instance>[] = [
    {
      accessorKey: "name",
      header: "Name",
      cell: ({ row }) => (
        <div className="font-medium" data-testid={`instance-name-${row.original.id}`}>
          {row.getValue("name")}
        </div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <Badge 
            className={
              status === "running" 
                ? "bg-green-100 text-green-800" 
                : status === "stopped"
                ? "bg-yellow-100 text-yellow-800"
                : "bg-gray-100 text-gray-800"
            }
            data-testid={`instance-status-${row.original.id}`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        );
      },
    },
    {
      accessorKey: "type",
      header: "Type",
      cell: ({ row }) => (
        <span data-testid={`instance-type-${row.original.id}`}>
          {row.getValue("type")}
        </span>
      ),
    },
    {
      accessorKey: "ipAddress",
      header: "IP Address",
      cell: ({ row }) => (
        <span data-testid={`instance-ip-${row.original.id}`}>
          {row.getValue("ipAddress") || "Pending"}
        </span>
      ),
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }) => {
        const date = new Date(row.getValue("createdAt"));
        return (
          <span data-testid={`instance-created-${row.original.id}`}>
            {date.toLocaleDateString()}
          </span>
        );
      },
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const instance = row.original;
        const isRunning = instance.status === "running";
        const isStarting = startInstanceMutation.isPending;
        const isStopping = stopInstanceMutation.isPending;
        const isDeleting = deleteInstanceMutation.isPending;

        return (
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => isRunning ? stopInstanceMutation.mutate(instance.id) : startInstanceMutation.mutate(instance.id)}
              disabled={isStarting || isStopping}
              className={isRunning ? "text-yellow-600 hover:text-yellow-700" : "text-aws-accent hover:text-blue-700"}
              data-testid={`button-${isRunning ? 'stop' : 'start'}-${instance.id}`}
            >
              {isRunning ? <Square className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => deleteInstanceMutation.mutate(instance.id)}
              disabled={isDeleting}
              className="text-red-600 hover:text-red-700"
              data-testid={`button-delete-${instance.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-aws-text mb-2" data-testid="text-instances-title">Instances</h2>
          <p className="text-gray-600" data-testid="text-instances-description">Manage your cloud instances</p>
        </div>
        <Button 
          onClick={() => setShowCreateModal(true)}
          className="bg-aws-secondary hover:bg-orange-600 w-full sm:w-auto"
          data-testid="button-create-instance"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Instance
        </Button>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card data-testid="card-instances-table">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold" data-testid="text-instances-table-title">Running Instances</h3>
          </div>
          <CardContent className="p-0">
            <DataTable columns={columns} data={instances} />
          </CardContent>
        </Card>
      )}

      <CreateInstanceModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal}
      />
    </div>
  );
}
