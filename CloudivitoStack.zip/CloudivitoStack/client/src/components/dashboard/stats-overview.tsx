import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import CreateInstanceModal from "./create-instance-modal";
import { useState } from "react";
import { 
  Server, 
  DollarSign, 
  Database, 
  Network,
  Plus,
  CheckCircle,
  Clock,
  Shield,
  TrendingUp
} from "lucide-react";
import type { Instance } from "@shared/schema";

export default function StatsOverview() {
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: stats, isLoading } = useQuery<{
    activeInstances: number;
    monthlyUsage: string;
    storageUsed: string;
    dataTransfer: string;
  }>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: instances = [] } = useQuery<Instance[]>({
    queryKey: ["/api/instances"],
  });

  const recentActivities = [
    {
      id: 1,
      type: 'success',
      message: 'Instance web-server-01 started',
      time: '2 minutes ago',
      icon: CheckCircle,
      color: 'text-aws-success'
    },
    {
      id: 2,
      type: 'info',
      message: 'New instance database-01 created',
      time: '1 hour ago',
      icon: Plus,
      color: 'text-aws-secondary'
    },
    {
      id: 3,
      type: 'security',
      message: 'Security group updated',
      time: '3 hours ago',
      icon: Shield,
      color: 'text-aws-accent'
    }
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 animate-pulse">
              <div className="h-12 bg-gray-200 rounded mb-4"></div>
              <div className="h-8 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-aws-text mb-2" data-testid="text-overview-title">Dashboard Overview</h2>
        <p className="text-gray-600" data-testid="text-overview-description">Monitor your cloud infrastructure at a glance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
        <Card className="border border-gray-200" data-testid="card-active-instances">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Instances</p>
                <p className="text-2xl font-bold text-aws-text" data-testid="text-active-instances">
                  {instances.filter((i: Instance) => i.status === 'running').length}
                </p>
              </div>
              <div className="bg-aws-success text-white w-12 h-12 rounded-lg flex items-center justify-center">
                <Server className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border border-gray-200" data-testid="card-monthly-usage">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monthly Usage</p>
                <p className="text-2xl font-bold text-aws-text" data-testid="text-monthly-usage">
                  {stats?.monthlyUsage || '₱0.00'}
                </p>
              </div>
              <div className="bg-aws-secondary text-white w-12 h-12 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border border-gray-200" data-testid="card-storage-used">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Storage Used</p>
                <p className="text-2xl font-bold text-aws-text" data-testid="text-storage-used">
                  {stats?.storageUsed || '0GB'}
                </p>
              </div>
              <div className="bg-aws-accent text-white w-12 h-12 rounded-lg flex items-center justify-center">
                <Database className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        
      </div>

      {/* My Instances Section */}
      <div className="mb-6 md:mb-8">
        <h3 className="text-lg font-semibold mb-4 text-aws-text">My Instances</h3>
        <Card className="border border-gray-200" data-testid="card-my-instances">
          <CardContent className="p-6">
            {instances.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Server className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-sm text-gray-500">No instances created yet</p>
                <p className="text-xs text-gray-400 mt-1">Create your first instance to get started</p>
              </div>
            ) : (
              <div className="space-y-3">
                {instances.slice(0, 3).map((instance: Instance) => (
                  <div key={instance.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        instance.status === 'running' ? 'bg-green-500' : 
                        instance.status === 'stopped' ? 'bg-red-500' : 'bg-yellow-500'
                      }`}></div>
                      <div>
                        <p className="font-medium text-sm">{instance.name}</p>
                        <p className="text-xs text-gray-500">{instance.operatingSystem} • {instance.ipAddress || 'No IP'}</p>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 capitalize">
                      {instance.status}
                    </div>
                  </div>
                ))}
                {instances.length > 3 && (
                  <div className="text-center pt-3 border-t">
                    <p className="text-xs text-gray-500">+{instances.length - 3} more instances</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <Card className="border border-gray-200" data-testid="card-recent-activity">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold" data-testid="text-recent-activity-title">Recent Activity</h3>
          </div>
          <CardContent className="p-6">
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Clock className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-sm text-gray-500">No recent activity</p>
              <p className="text-xs text-gray-400 mt-1">Your activity history will appear here</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-200" data-testid="card-quick-actions">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold" data-testid="text-quick-actions-title">Quick Actions</h3>
          </div>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Current Plan</span>
                <span className="font-medium text-aws-primary" data-testid="text-current-plan">
                  {stats?.subscriptionPlan || 'Free Plan'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Instances Used</span>
                <span className="font-medium" data-testid="text-instances-usage">
                  {stats?.instancesUsed || 0} / {stats?.instancesLimit || 3}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-aws-accent h-2 rounded-full transition-all" 
                  style={{ width: `${((stats?.instancesUsed || 0) / (stats?.instancesLimit || 3)) * 100}%` }}
                  data-testid="progress-instances-usage"
                ></div>
              </div>
              <Button 
                onClick={() => setShowCreateModal(true)}
                className="bg-aws-secondary hover:bg-orange-600 text-white w-full p-3 h-auto flex items-center justify-center space-x-2"
                data-testid="button-create-instance"
              >
                <Plus className="w-6 h-6" />
                <span className="text-sm font-medium">Create Instance</span>
              </Button>
              
              <Button 
                variant="outline"
                className="border-aws-accent text-aws-accent hover:bg-aws-accent hover:text-white p-4 h-auto flex flex-col items-center space-y-2"
                data-testid="button-setup-network"
              >
                <Network className="w-6 h-6" />
                <span className="text-sm font-medium">Setup Network</span>
              </Button>
              
              <Button 
                variant="outline"
                className="border-aws-success text-aws-success hover:bg-aws-success hover:text-white p-4 h-auto flex flex-col items-center space-y-2"
                data-testid="button-add-storage"
              >
                <Database className="w-6 h-6" />
                <span className="text-sm font-medium">Add Storage</span>
              </Button>
              
              <Button 
                variant="outline"
                className="border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white p-4 h-auto flex flex-col items-center space-y-2"
                data-testid="button-view-metrics"
              >
                <TrendingUp className="w-6 h-6" />
                <span className="text-sm font-medium">View Metrics</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <CreateInstanceModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal}
      />
    </div>
  );
}
