import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { 
  LayoutDashboard, 
  Server, 
  Network, 
  Database, 
  CreditCard, 
  TrendingUp, 
  Settings,
  X
} from "lucide-react";

const navigation = [
  { name: "Overview", href: "/", icon: LayoutDashboard },
  { name: "Billing", href: "/billing", icon: CreditCard },
  { name: "Settings", href: "/settings", icon: Settings },
];

interface SidebarProps {
  isMobileMenuOpen?: boolean;
  onMobileMenuClose?: () => void;
}

export default function Sidebar({ isMobileMenuOpen = false, onMobileMenuClose }: SidebarProps) {
  const [location] = useLocation();

  const NavigationList = () => (
    <ul className="space-y-2">
      {navigation.map((item) => {
        const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
        const Icon = item.icon;
        
        return (
          <li key={item.name}>
            <Link href={item.href}>
              <a 
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                  isActive
                    ? "text-aws-primary bg-blue-50"
                    : "text-gray-700 hover:text-aws-primary hover:bg-gray-50"
                )}
                data-testid={`link-nav-${item.name.toLowerCase()}`}
                onClick={() => onMobileMenuClose?.()}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </a>
            </Link>
          </li>
        );
      })}
    </ul>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <nav className="hidden md:block bg-white w-64 min-h-screen border-r border-gray-200" data-testid="nav-sidebar">
        <div className="p-6">
          <NavigationList />
        </div>
      </nav>

      {/* Mobile Drawer */}
      <Sheet open={isMobileMenuOpen} onOpenChange={onMobileMenuClose}>
        <SheetContent side="left" className="w-64 p-0" data-testid="nav-mobile-sidebar">
          <SheetHeader className="px-6 py-4 border-b border-gray-200">
            <SheetTitle className="text-lg font-semibold text-aws-primary">Cloudivito</SheetTitle>
          </SheetHeader>
          <div className="p-6">
            <NavigationList />
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
