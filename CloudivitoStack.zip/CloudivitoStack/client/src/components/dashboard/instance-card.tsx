import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Server, 
  Play, 
  Square, 
  Trash2, 
  Calendar,
  HardDrive,
  Network
} from "lucide-react";

interface Instance {
  id: string;
  name: string;
  status: string;
  type: string;
  ipAddress: string | null;
  operatingSystem: string;
  storageSize: number;
  createdAt: string;
  monthlyEstimate?: string;
}

interface InstanceCardProps {
  instance: Instance;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
  onDelete: (id: string) => void;
  isStarting?: boolean;
  isStopping?: boolean;
  isDeleting?: boolean;
}

export default function InstanceCard({ 
  instance, 
  onStart, 
  onStop, 
  onDelete,
  isStarting = false,
  isStopping = false,
  isDeleting = false
}: InstanceCardProps) {
  const isRunning = instance.status === "running";
  const isStopped = instance.status === "stopped";
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-green-100 text-green-800";
      case "stopped":
        return "bg-yellow-100 text-yellow-800";
      case "starting":
        return "bg-blue-100 text-blue-800";
      case "stopping":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getOSDisplayName = (os: string) => {
    switch (os) {
      case "ubuntu":
        return "Ubuntu 22.04";
      case "centos":
        return "CentOS 9";
      default:
        return os.charAt(0).toUpperCase() + os.slice(1);
    }
  };

  return (
    <Card 
      className="hover:shadow-lg transition-shadow border border-gray-200"
      data-testid={`card-instance-${instance.id}`}
    >
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="bg-aws-accent text-white w-10 h-10 rounded-lg flex items-center justify-center">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 
                className="text-lg font-semibold text-aws-text"
                data-testid={`text-instance-name-${instance.id}`}
              >
                {instance.name}
              </h3>
              <p 
                className="text-sm text-gray-600"
                data-testid={`text-instance-type-${instance.id}`}
              >
                {instance.type}
              </p>
            </div>
          </div>
          <Badge 
            className={getStatusColor(instance.status)}
            data-testid={`badge-status-${instance.id}`}
          >
            {instance.status.charAt(0).toUpperCase() + instance.status.slice(1)}
          </Badge>
        </div>

        {/* Instance Details */}
        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600 flex items-center">
              <Network className="w-4 h-4 mr-2" />
              IP Address:
            </span>
            <span 
              className="font-medium"
              data-testid={`text-instance-ip-${instance.id}`}
            >
              {instance.ipAddress || "Pending"}
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600 flex items-center">
              <HardDrive className="w-4 h-4 mr-2" />
              Storage:
            </span>
            <span 
              className="font-medium"
              data-testid={`text-instance-storage-${instance.id}`}
            >
              {instance.storageSize}GB
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">OS:</span>
            <span 
              className="font-medium"
              data-testid={`text-instance-os-${instance.id}`}
            >
              {getOSDisplayName(instance.operatingSystem)}
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600 flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Created:
            </span>
            <span 
              className="font-medium"
              data-testid={`text-instance-created-${instance.id}`}
            >
              {formatDate(instance.createdAt)}
            </span>
          </div>
        </div>

        {/* Monthly Estimate */}
        {instance.monthlyEstimate && (
          <div className="bg-gray-50 rounded-lg p-3 mb-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Monthly Estimate:</span>
              <span 
                className="font-semibold text-aws-text"
                data-testid={`text-instance-estimate-${instance.id}`}
              >
                {instance.monthlyEstimate}
              </span>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between space-x-2">
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => isRunning ? onStop(instance.id) : onStart(instance.id)}
              disabled={isStarting || isStopping}
              className={`
                ${isRunning 
                  ? "border-yellow-600 text-yellow-600 hover:bg-yellow-50" 
                  : "border-aws-accent text-aws-accent hover:bg-blue-50"
                }
              `}
              data-testid={`button-${isRunning ? 'stop' : 'start'}-${instance.id}`}
            >
              {isStarting ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-aws-accent"></div>
              ) : isStopping ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-600"></div>
              ) : isRunning ? (
                <>
                  <Square className="w-4 h-4 mr-1" />
                  Stop
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-1" />
                  Start
                </>
              )}
            </Button>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(instance.id)}
            disabled={isDeleting}
            className="border-red-600 text-red-600 hover:bg-red-50"
            data-testid={`button-delete-${instance.id}`}
          >
            {isDeleting ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
            ) : (
              <>
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
