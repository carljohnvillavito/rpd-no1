import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CreditCard, Download } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import type { BillingRecord, UsageMetric } from "@shared/schema";

export default function BillingSection() {
  const { data: billingRecords = [], isLoading: isLoadingBilling } = useQuery<BillingRecord[]>({
    queryKey: ["/api/billing/records"],
  });

  const { data: usageMetrics = [], isLoading: isLoadingUsage } = useQuery<UsageMetric[]>({
    queryKey: ["/api/usage/metrics"],
  });

  // Mock data for display purposes since we don't have real billing data yet
  const currentPlan = {
    name: "Pro Plan",
    price: "$29.00",
    description: "5 instances, 8GB RAM each, Priority support",
    status: "active"
  };

  const usage = {
    computeHours: { used: 124, total: 200, percentage: 62 },
    storage: { used: 45, total: 100, percentage: 45 },
    dataTransfer: { used: 1.2, total: 5.0, percentage: 24 }
  };

  const paymentMethod = {
    cardNumber: "•••• •••• •••• 4242",
    expiry: "12/25",
    nextBillingDate: "March 15, 2024"
  };

  const mockInvoices = [
    {
      id: "1",
      date: "Feb 15, 2024",
      amount: "$29.00",
      status: "paid"
    },
    {
      id: "2", 
      date: "Jan 15, 2024",
      amount: "$29.00",
      status: "paid"
    }
  ];

  const invoiceColumns: ColumnDef<any>[] = [
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }) => (
        <span data-testid={`invoice-date-${row.original.id}`}>
          {row.getValue("date")}
        </span>
      ),
    },
    {
      accessorKey: "amount",
      header: "Amount",
      cell: ({ row }) => (
        <span data-testid={`invoice-amount-${row.original.id}`}>
          {row.getValue("amount")}
        </span>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <Badge 
            className="bg-green-100 text-green-800"
            data-testid={`invoice-status-${row.original.id}`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        );
      },
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => (
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-aws-accent hover:text-blue-700"
          data-testid={`button-download-${row.original.id}`}
        >
          <Download className="w-4 h-4 mr-1" />
          Download
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-aws-text mb-2" data-testid="text-billing-title">Billing & Usage</h2>
        <p className="text-gray-600" data-testid="text-billing-description">Manage your subscription and monitor usage</p>
      </div>

      {/* Current Plan Card */}
      <Card className="border border-gray-200" data-testid="card-current-plan">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
            <div>
              <h3 className="text-lg font-semibold mb-2">Current Plan</h3>
              <div className="flex items-center space-x-4">
                <span className="text-2xl font-bold text-aws-primary" data-testid="text-plan-name">
                  {currentPlan.name}
                </span>
                <Badge className="bg-aws-success text-white" data-testid="badge-plan-status">
                  {currentPlan.status.toUpperCase()}
                </Badge>
              </div>
              <p className="text-gray-600 mt-2" data-testid="text-plan-description">
                {currentPlan.description}
              </p>
            </div>
            <div className="text-left sm:text-right">
              <p className="text-2xl font-bold text-aws-text" data-testid="text-plan-price">
                {currentPlan.price}
              </p>
              <p className="text-gray-500">per month</p>
              <Button 
                className="mt-2 bg-aws-accent hover:bg-blue-700"
                data-testid="button-upgrade-plan"
              >
                Upgrade Plan
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-4 md:mb-6">
        <Card className="border border-gray-200" data-testid="card-usage-overview">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Current Month Usage</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Compute Hours</span>
                  <span className="text-sm font-medium" data-testid="text-compute-usage">
                    {usage.computeHours.used} / {usage.computeHours.total}
                  </span>
                </div>
                <Progress value={usage.computeHours.percentage} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Storage</span>
                  <span className="text-sm font-medium" data-testid="text-storage-usage">
                    {usage.storage.used} / {usage.storage.total} GB
                  </span>
                </div>
                <Progress value={usage.storage.percentage} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Data Transfer</span>
                  <span className="text-sm font-medium" data-testid="text-transfer-usage">
                    {usage.dataTransfer.used} / {usage.dataTransfer.total} TB
                  </span>
                </div>
                <Progress value={usage.dataTransfer.percentage} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-200" data-testid="card-payment-method">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Payment Method</h3>
            <div className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
              <div className="bg-gray-100 p-2 rounded">
                <CreditCard className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="font-medium" data-testid="text-card-number">
                  {paymentMethod.cardNumber}
                </p>
                <p className="text-sm text-gray-600" data-testid="text-card-expiry">
                  Expires {paymentMethod.expiry}
                </p>
              </div>
              <Button 
                variant="ghost" 
                className="ml-auto text-aws-accent hover:text-blue-700 text-sm font-medium"
                data-testid="button-update-payment"
              >
                Update
              </Button>
            </div>
            <p className="text-sm text-gray-600 mt-4">
              Next billing date: <span className="font-medium" data-testid="text-next-billing">
                {paymentMethod.nextBillingDate}
              </span>
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Invoice History */}
      <Card className="border border-gray-200" data-testid="card-invoice-history">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold" data-testid="text-invoice-history-title">Invoice History</h3>
        </div>
        <CardContent className="p-0">
          <DataTable columns={invoiceColumns} data={mockInvoices} />
        </CardContent>
      </Card>
    </div>
  );
}
