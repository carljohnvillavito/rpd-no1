# Overview

This is a cloud infrastructure management platform built with React and Express that provides AWS-like cloud instance management capabilities. The application allows users to create, manage, and monitor virtual instances using Incus containerization technology. It features a modern dashboard interface for managing cloud resources, billing, and user accounts with integrated authentication through Replit's OpenID Connect system.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Single-page application using functional components and hooks
- **shadcn/ui Component Library**: Modern UI components built on Radix UI primitives with Tailwind CSS styling
- **Client-side Routing**: Uses Wouter for lightweight routing between dashboard sections
- **State Management**: TanStack Query for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form schemas
- **Styling**: Tailwind CSS with custom AWS-inspired color palette and design system

## Backend Architecture
- **Express.js Server**: RESTful API with TypeScript support
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Authentication**: Passport.js with OpenID Connect strategy for Replit authentication
- **Session Management**: Express sessions with PostgreSQL session store
- **API Design**: RESTful endpoints for instance management, billing, and user operations

## Data Storage
- **PostgreSQL Database**: Primary data store using Neon serverless PostgreSQL
- **Database Schema**: 
  - Users table for authentication and profile data
  - Instances table for cloud resource management
  - Billing records and usage metrics for cost tracking
  - Sessions table for authentication state
- **ORM**: Drizzle ORM with schema-first approach and automatic TypeScript type generation

## Authentication and Authorization
- **OpenID Connect**: Integration with Replit's authentication system
- **Session-based Auth**: Secure session management with PostgreSQL persistence
- **Route Protection**: Middleware-based authentication checks on protected endpoints
- **User Management**: Automatic user creation and profile management

## External Dependencies
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Replit Authentication**: OpenID Connect provider for user authentication
- **Incus API**: Container orchestration for virtual instance management
- **shadcn/ui**: Component library ecosystem including Radix UI primitives
- **Vite**: Development server and build tool with hot module replacement