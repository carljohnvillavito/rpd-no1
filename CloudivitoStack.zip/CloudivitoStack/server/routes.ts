import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertInstanceSchema, subscriptionPlans } from "@shared/schema";
import { incusApi } from "./services/incusApi";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Instance management routes
  app.get('/api/instances', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const instances = await storage.getUserInstances(userId);
      res.json(instances);
    } catch (error) {
      console.error("Error fetching instances:", error);
      res.status(500).json({ message: "Failed to fetch instances" });
    }
  });

  app.post('/api/instances', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Check if user can create more instances
      const canCreate = await storage.canCreateInstance(userId);
      if (!canCreate.allowed) {
        return res.status(400).json({ message: canCreate.reason });
      }
      
      // Validate request body
      const createInstanceData = insertInstanceSchema.parse({
        ...req.body,
        userId,
      });

      // Generate IP address
      const ipAddress = incusApi.generateIPAddress();

      // Create instance in Incus
      const incusContainerId = await incusApi.createInstance({
        name: createInstanceData.name,
        type: createInstanceData.type,
        operatingSystem: createInstanceData.operatingSystem,
        storageSize: createInstanceData.storageSize,
      });

      // Start the instance
      await incusApi.startInstance(createInstanceData.name);

      // Create database record (will apply subscription limits automatically)
      const instance = await storage.createInstance({
        ...createInstanceData,
        ipAddress,
        incusContainerId,
        status: 'starting',
      });

      // Update status to running after successful start
      const updatedInstance = await storage.updateInstance(instance.id, {
        status: 'running',
      });

      res.json(updatedInstance);
    } catch (error) {
      console.error("Error creating instance:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create instance" 
      });
    }
  });

  app.patch('/api/instances/:id/start', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const instance = await storage.getInstance(id);
      
      if (!instance) {
        return res.status(404).json({ message: "Instance not found" });
      }

      // Check if user owns this instance
      if (instance.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Start instance in Incus
      if (instance.incusContainerId) {
        await incusApi.startInstance(instance.incusContainerId);
      }

      // Update database
      const updatedInstance = await storage.updateInstance(id, {
        status: 'running',
      });

      res.json(updatedInstance);
    } catch (error) {
      console.error("Error starting instance:", error);
      res.status(500).json({ message: "Failed to start instance" });
    }
  });

  app.patch('/api/instances/:id/stop', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const instance = await storage.getInstance(id);
      
      if (!instance) {
        return res.status(404).json({ message: "Instance not found" });
      }

      // Check if user owns this instance
      if (instance.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Stop instance in Incus
      if (instance.incusContainerId) {
        await incusApi.stopInstance(instance.incusContainerId);
      }

      // Update database
      const updatedInstance = await storage.updateInstance(id, {
        status: 'stopped',
      });

      res.json(updatedInstance);
    } catch (error) {
      console.error("Error stopping instance:", error);
      res.status(500).json({ message: "Failed to stop instance" });
    }
  });

  app.delete('/api/instances/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const instance = await storage.getInstance(id);
      
      if (!instance) {
        return res.status(404).json({ message: "Instance not found" });
      }

      // Check if user owns this instance
      if (instance.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Delete instance in Incus
      if (instance.incusContainerId) {
        await incusApi.deleteInstance(instance.incusContainerId);
      }

      // Delete from database
      await storage.deleteInstance(id);

      res.json({ message: "Instance deleted successfully" });
    } catch (error) {
      console.error("Error deleting instance:", error);
      res.status(500).json({ message: "Failed to delete instance" });
    }
  });

  // Billing routes
  app.get('/api/billing/records', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const records = await storage.getUserBillingRecords(userId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching billing records:", error);
      res.status(500).json({ message: "Failed to fetch billing records" });
    }
  });

  // Usage metrics routes
  app.get('/api/usage/metrics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { type } = req.query;
      const metrics = await storage.getUserUsageMetrics(userId, type as string);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching usage metrics:", error);
      res.status(500).json({ message: "Failed to fetch usage metrics" });
    }
  });

  // Subscription management routes
  app.get('/api/subscription/plans', async (req, res) => {
    res.json(subscriptionPlans);
  });
  
  app.get('/api/subscription/current', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const currentPlan = user?.subscriptionPlan || "free";
      const planDetails = subscriptionPlans[currentPlan as keyof typeof subscriptionPlans];
      const instances = await storage.getUserInstances(userId);
      
      res.json({
        plan: currentPlan,
        details: planDetails,
        usedInstances: instances.length,
        maxInstances: planDetails.instanceLimit,
        subscriptionExpiry: user?.subscriptionExpiry,
      });
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  // Dashboard stats route
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get user instances
      const instances = await storage.getUserInstances(userId);
      const activeInstances = instances.filter(i => i.status === 'running').length;
      const user = await storage.getUser(userId);
      const currentPlan = subscriptionPlans[user?.subscriptionPlan as keyof typeof subscriptionPlans] || subscriptionPlans.free;
      
      // Get current month usage metrics
      const usageMetrics = await storage.getUserUsageMetrics(userId);
      
      // Calculate stats (simplified)
      const stats = {
        activeInstances,
        monthlyUsage: `${currentPlan.currency}${currentPlan.price}.00`,
        storageUsed: `${instances.reduce((sum, i) => sum + (i.storageSize || 0), 0)}GB`,
        dataTransfer: '1.2TB', // This would come from actual metrics
        subscriptionPlan: currentPlan.name,
        instancesUsed: instances.length,
        instancesLimit: currentPlan.instanceLimit,
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
