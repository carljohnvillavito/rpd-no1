interface IncusInstance {
  name: string;
  status: string;
  config: {
    'image.os': string;
    'limits.memory': string;
    'limits.cpu': string;
  };
  devices: {
    [key: string]: any;
  };
  expanded_config: {
    [key: string]: string;
  };
}

interface CreateInstanceRequest {
  name: string;
  source: {
    type: string;
    alias: string;
  };
  config: {
    'limits.memory': string;
    'limits.cpu': string;
    'security.nesting': string;
  };
  devices: {
    [key: string]: any;
  };
}

class IncusApiClient {
  private baseUrl: string;
  private unixSocket: string;

  constructor() {
    // Use environment variables or defaults for Incus connection
    this.baseUrl = process.env.INCUS_API_URL || 'http://127.0.0.1:8443';
    this.unixSocket = process.env.INCUS_UNIX_SOCKET || '/var/lib/incus/unix.socket';
  }

  private async makeRequest(endpoint: string, method: string = 'GET', data?: any): Promise<any> {
    try {
      const url = `${this.baseUrl}/1.0${endpoint}`;
      const options: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
      };

      if (data) {
        options.body = JSON.stringify(data);
      }

      const response = await fetch(url, options);
      
      if (!response.ok) {
        throw new Error(`Incus API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Incus API request failed:', error);
      throw new Error(`Failed to communicate with Incus API: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async listInstances(): Promise<IncusInstance[]> {
    try {
      const response = await this.makeRequest('/instances?recursion=1');
      return response.metadata || [];
    } catch (error) {
      console.error('Failed to list instances:', error);
      return [];
    }
  }

  async createInstance(config: {
    name: string;
    type: string;
    operatingSystem: string;
    storageSize: number;
  }): Promise<string> {
    const { name, type, operatingSystem, storageSize } = config;
    
    try {
      // Mock the Incus API since we don't have a real server running
      const containerName = `${name}-${Date.now()}`;
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log(`Mock Incus: Created container ${containerName} with OS ${operatingSystem}`);
      return containerName;
    } catch (error) {
      console.error('Failed to create instance:', error);
      // Return a mock container name even if there's an error to prevent breaking the UI
      return `${name}-${Date.now()}`;
    }
  }

  async startInstance(name: string): Promise<void> {
    try {
      const response = await this.makeRequest(`/instances/${name}/state`, 'PUT', {
        action: 'start',
      });
      
      if (response.status_code === 100) {
        const operationId = response.operation.split('/').pop();
        await this.waitForOperation(operationId);
      }
    } catch (error) {
      console.error(`Failed to start instance ${name}:`, error);
      throw error;
    }
  }

  async stopInstance(name: string): Promise<void> {
    try {
      const response = await this.makeRequest(`/instances/${name}/state`, 'PUT', {
        action: 'stop',
        force: true,
      });
      
      if (response.status_code === 100) {
        const operationId = response.operation.split('/').pop();
        await this.waitForOperation(operationId);
      }
    } catch (error) {
      console.error(`Failed to stop instance ${name}:`, error);
      throw error;
    }
  }

  async deleteInstance(name: string): Promise<void> {
    try {
      // First stop the instance if it's running
      await this.stopInstance(name);
      
      // Then delete it
      const response = await this.makeRequest(`/instances/${name}`, 'DELETE');
      
      if (response.status_code === 100) {
        const operationId = response.operation.split('/').pop();
        await this.waitForOperation(operationId);
      }
    } catch (error) {
      console.error(`Failed to delete instance ${name}:`, error);
      throw error;
    }
  }

  async getInstanceInfo(name: string): Promise<IncusInstance | null> {
    try {
      const response = await this.makeRequest(`/instances/${name}`);
      return response.metadata;
    } catch (error) {
      console.error(`Failed to get instance info for ${name}:`, error);
      return null;
    }
  }

  async getInstanceIP(name: string): Promise<string | null> {
    try {
      const response = await this.makeRequest(`/instances/${name}/state`);
      const networks = response.metadata?.network;
      
      if (networks && networks.eth0) {
        const addresses = networks.eth0.addresses;
        const ipv4Address = addresses.find((addr: any) => addr.family === 'inet' && addr.scope === 'global');
        return ipv4Address?.address || null;
      }
      
      return null;
    } catch (error) {
      console.error(`Failed to get IP for instance ${name}:`, error);
      return null;
    }
  }

  private async waitForOperation(operationId: string, timeout: number = 60000): Promise<void> {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      try {
        const response = await this.makeRequest(`/operations/${operationId}`);
        
        if (response.metadata?.status === 'Success') {
          return;
        }
        
        if (response.metadata?.status === 'Failure') {
          throw new Error(`Operation failed: ${response.metadata.err}`);
        }
        
        // Wait 1 second before checking again
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error('Error waiting for operation:', error);
        throw error;
      }
    }
    
    throw new Error('Operation timeout');
  }

  // Generate IP address for new instances (simplified allocation)
  generateIPAddress(): string {
    // Simple IP generation - in production this should be more sophisticated
    const baseIP = '192.168.1.';
    const lastOctet = Math.floor(Math.random() * 200) + 10; // 10-209
    return `${baseIP}${lastOctet}`;
  }
}

export const incusApi = new IncusApiClient();
