import {
  users,
  instances,
  billingRecords,
  usageMetrics,
  subscriptionPlans,
  type User,
  type UpsertUser,
  type Instance,
  type InsertInstance,
  type BillingRecord,
  type InsertBillingRecord,
  type UsageMetric,
  type InsertUsageMetric,
  type SubscriptionPlanType,
  type UpdateUserSubscription,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, ne } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserSubscription(userId: string, subscription: UpdateUserSubscription): Promise<User>;
  getUserPlan(userId: string): Promise<SubscriptionPlanType>;
  
  // Instance operations
  getUserInstances(userId: string): Promise<Instance[]>;
  createInstance(instance: InsertInstance): Promise<Instance>;
  updateInstance(id: string, updates: Partial<Instance>): Promise<Instance>;
  deleteInstance(id: string): Promise<void>;
  getInstance(id: string): Promise<Instance | undefined>;
  canCreateInstance(userId: string): Promise<{ allowed: boolean; reason?: string }>;
  deleteUserPremiumInstances(userId: string): Promise<void>;
  
  // Billing operations
  getUserBillingRecords(userId: string): Promise<BillingRecord[]>;
  createBillingRecord(record: InsertBillingRecord): Promise<BillingRecord>;
  
  // Usage metrics operations
  getUserUsageMetrics(userId: string, metricType?: string): Promise<UsageMetric[]>;
  createUsageMetric(metric: InsertUsageMetric): Promise<UsageMetric>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // If userData has an id, try to update, otherwise insert
    if (userData.id) {
      const [user] = await db
        .insert(users)
        .values(userData)
        .onConflictDoUpdate({
          target: users.id,
          set: {
            ...userData,
            updatedAt: new Date(),
          },
        })
        .returning();
      return user;
    } else {
      const [user] = await db
        .insert(users)
        .values(userData)
        .returning();
      return user;
    }
  }

  async updateUserSubscription(userId: string, subscription: UpdateUserSubscription): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...subscription,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getUserPlan(userId: string): Promise<SubscriptionPlanType> {
    const user = await this.getUser(userId);
    return (user?.subscriptionPlan as SubscriptionPlanType) || "free";
  }

  // Instance operations
  async getUserInstances(userId: string): Promise<Instance[]> {
    return await db
      .select()
      .from(instances)
      .where(eq(instances.userId, userId))
      .orderBy(desc(instances.createdAt));
  }

  async createInstance(instance: InsertInstance): Promise<Instance> {
    const userPlan = await this.getUserPlan(instance.userId);
    const planLimits = subscriptionPlans[userPlan];
    
    const finalInstanceData = {
      ...instance,
      vcpu: planLimits.vcpu.toString(),
      memory: planLimits.memory,
      createdByPlan: userPlan,
    };
    
    const [newInstance] = await db
      .insert(instances)
      .values(finalInstanceData)
      .returning();
    return newInstance;
  }

  async updateInstance(id: string, updates: Partial<Instance>): Promise<Instance> {
    const [updatedInstance] = await db
      .update(instances)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(instances.id, id))
      .returning();
    return updatedInstance;
  }

  async deleteInstance(id: string): Promise<void> {
    await db.delete(instances).where(eq(instances.id, id));
  }

  async getInstance(id: string): Promise<Instance | undefined> {
    const [instance] = await db.select().from(instances).where(eq(instances.id, id));
    return instance;
  }

  async canCreateInstance(userId: string): Promise<{ allowed: boolean; reason?: string }> {
    const userPlan = await this.getUserPlan(userId);
    const planLimits = subscriptionPlans[userPlan];
    const userInstances = await this.getUserInstances(userId);
    
    if (userInstances.length >= planLimits.instanceLimit) {
      return {
        allowed: false,
        reason: `You have reached your ${planLimits.name} limit of ${planLimits.instanceLimit} instances. Please upgrade your plan or delete existing instances.`
      };
    }
    
    return { allowed: true };
  }

  async deleteUserPremiumInstances(userId: string): Promise<void> {
    // Delete all instances that were created by paid plans (not free plan)
    await db
      .delete(instances)
      .where(and(
        eq(instances.userId, userId),
        ne(instances.createdByPlan, "free")
      ));
  }

  // Billing operations
  async getUserBillingRecords(userId: string): Promise<BillingRecord[]> {
    return await db
      .select()
      .from(billingRecords)
      .where(eq(billingRecords.userId, userId))
      .orderBy(desc(billingRecords.billingDate));
  }

  async createBillingRecord(record: InsertBillingRecord): Promise<BillingRecord> {
    const [newRecord] = await db
      .insert(billingRecords)
      .values(record)
      .returning();
    return newRecord;
  }

  // Usage metrics operations
  async getUserUsageMetrics(userId: string, metricType?: string): Promise<UsageMetric[]> {
    if (metricType) {
      return await db.select().from(usageMetrics).where(and(
        eq(usageMetrics.userId, userId),
        eq(usageMetrics.metricType, metricType)
      )).orderBy(desc(usageMetrics.timestamp));
    }
    
    return await db.select().from(usageMetrics).where(eq(usageMetrics.userId, userId)).orderBy(desc(usageMetrics.timestamp));
  }

  async createUsageMetric(metric: InsertUsageMetric): Promise<UsageMetric> {
    const [newMetric] = await db
      .insert(usageMetrics)
      .values(metric)
      .returning();
    return newMetric;
  }
}

export const storage = new DatabaseStorage();
